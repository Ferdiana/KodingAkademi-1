import {Stack, Text} from 'native-base';
import React from 'react';

const SearchScreen = () => {
  return (
    <Stack>
      <Text>ini SearchScreen</Text>
    </Stack>
  );
};
export default SearchScreen;
